using Terraria;
using Terraria.ModLoader;
using Terraria.ID;

namespace rancher.NPCs
{
    public class SeaSlime : ModNPC
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Simple Slime");
        }

        public override void SetDefaults()
        {
            npc.width = 30;
            npc.height = 30;
            npc.damage = 13;
            npc.defense = 2;
            npc.lifeMax = 20;
            npc.HitSound = SoundID.NPCHit2;
            npc.DeathSound = SoundID.NPCDeath2;
            npc.value = 150f;
            npc.knockBackResist = 0.00f;
            npc.aiStyle = 1;
            Main.npcFrameCount[npc.type] = Main.npcFrameCount[NPCID.BlueSlime]; //Main.npcFrameCount[2];
            aiType = NPCID.BlueSlime; // aiType = 2;
            animationType = NPCID.BlueSlime; // animationType = 2;aa
        }

        public override float SpawnChance(NPCSpawnInfo spawnInfo)
        {
            return SpawnCondition.OverworldWaterCritter.Chance * 0.9f;
			return SpawnCondition.Ocean.Chance * 1.3f;

        }
    }
}