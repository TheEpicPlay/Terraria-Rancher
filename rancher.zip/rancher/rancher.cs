using Terraria.ModLoader;

namespace rancher
{
	class rancher : Mod
	{
		public rancher()
		{
		}
	}
}
